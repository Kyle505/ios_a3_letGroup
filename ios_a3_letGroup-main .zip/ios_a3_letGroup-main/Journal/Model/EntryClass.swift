//
//  Entry+CoreDataClass.swift
//  Journal
//
//
//  Created by 王珈玮 on 2022/5/5.
//

import Foundation
import CoreData

@objc(Entry)
public class Entry: NSManagedObject {
    
}
