# Your Daily

## 42889 Application Development in the iOS

-Group: LetGroup

-Lab Time: Firday 15:30 pm

-Group Member:

Jiawei Wang 14210429

Difei Wu 13721752

Chao Wang 13668811

Chuanqiang Li 14111746



GitHub Link: https://github.com/Kyle505/ios_a3_letGroup
